;var jsconf = (function () {
    var targeted_id = 'home';
    var panel_width = 870;
    var left_edge = function() {
        return $("#navigation").offset().left;
    };
    var coords_for = function (id) {
      var x = 0;
      var y = 0;
      if (id == "articles" || id == "schedule" || id== "videos") {
          y = 110;
      } else if (id == "register" || id == "home" || id== "sponsors") {
          y = -439;
      } else if (id == "about" || id == "speakers" || id== "venue") {
          y = -990;
      }
      var navleft = left_edge();
      if (id == "articles" || id=="register" || id == "about")	{
          x = navleft + 10;
      } else if (id == "schedule" || id=="home" || id == "speakers")	{
          x = navleft - (panel_width);
      } else if (id == "videos" || id=="sponsors" || id == "venue")	{
          x = navleft - ((panel_width * 2) +13);
      }
      var obj = {"top": y, "left": x};
      return obj;
    };
    
    var refocus = function(easing) {
      var new_coords = coords_for(targeted_id);
      console.log("lxt: "+new_coords.left+"x"+new_coords.top);
      if (easing) {
         $("#viewpane").animate(new_coords);
      } else {
        $("#viewpane").css(new_coords);
      }
    };

    return {
      resizeContainer: function() {
        refocus();
      },
      focus_on: function(id) {
        targeted_id = id;
        refocus(true);
      },
      default_focus: function () {
        refocus(true);
      }
    }
})();

var t = null;

jQuery(document).ready(function() {
  jsconf.resizeContainer();
  $(window).resize(jsconf.resizeContainer);
  $("div.block").click(function(e) {
    jsconf.focus_on($(this).attr("id"));
  });
  $("#navigation a").click(function(e) {
    e.preventDefault();
    jsconf.focus_on($(this).attr("href").replace("#",""));
  });
    // 
    //     var curr_node = e.target;
    //     t = curr_node;
    //     while( curr_node.className != "block") {
    //         curr_node = curr_node.parentNode;
    //     }
    //     jsconf.focus_on(curr_node.id);
    // });
    // dojo.query("#navigation a").onclick(function(e) {
    //     var curr_node = e.target;
    //     var href = dojo.attr(curr_node, "href");
    //     if (!href) {
    //         href = dojo.attr(curr_node.parentNode, "href");
    //     }
    //     jsconf.focus_on(href.replace("#",""));
    // });
    // dojo.query("textarea").onclick(function(e) {
    //     e.target.focus();
    // });
    // var viewpane = new dojo.dnd.Moveable("viewpane");
    // dojo.subscribe("/dnd/move/stop", function(mover){ 
    //     jsconf.default_focus();;
    // });

});